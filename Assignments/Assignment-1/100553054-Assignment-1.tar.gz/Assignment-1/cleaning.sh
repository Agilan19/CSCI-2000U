    1  whoami
    2  cd
    3  ls
    4  pwd
    5  finger
    6  pwd
    7  ls
    8  dir
    9  -l
   10  ll
   11  alias ls div
   12  alias ls dir
   13  \ls
   14  ls-a
   15  ls/a
   16  ls\a
   17  ls\F
   18  doc
   19  ls-a
   20  cd Do
   21  cd\do
   22  pwd
   23  ls\doc
   24  mkdir turtorial ls
   25  mkdir tutorial ls
   26  cd tutorial/
   27  ls
   28  nano
   29  cp tutorial.txt
   30  cp tutorial2.txt
   31  cat tutorial
   32  mv tutorial2.txt tutorial3.txt
   33  cp tutorial.txt 'tutorial2.txt'
   34  rm tutorial3.txt
   35  rm turtorial.txt
   36  rm-i tutorial3.txt
   37  r-i turotial.txt
   38  pwd
   39  cd..
   40  cd
   41  cd Documents/
   42  pwd
   43  mkdir assignment_1
   44  pwd
   45  ls
   46  mv assignment_1/assignment
   47  mv assignment_1/ assignment
   48  ls
   49  ls assignment/ tutorial
   50  ls
   51  cd assignment/
   52  nano Assignment.txt
   53  rm assignment/
   54  rm-r assignment/
   55  ls
   56  rm-r/ Assignment
   57  rm-r/ Assignment.txt
   58  home
   59  cd
   60  home/
   61  cd ~
   62  ls
   63  cd -
   64  ls
   65  cd..
   66  pwd
   67  cd
   68  tutorial.txt
   69  mv tutorial.tx
   70  mv tutorial .txt
   71  ls
   72  cd-/Desktop
   73  ls
   74  cd -/Desktop
   75  ls
   76  pwd
   77  nel
   78  cd Downloads/
   79  ls
   80  pwd
   81  unzip shell-novice-data.zip
   82  ls -F
   83  cd data/
   84  ls
   85  ls Users/
   86  ls nelle
   87  le nelle/
   88  pwd
   89  ls Users/nelle
   90  c
   91  cd
   92  pwd
   93  cd Documents/
   94  ls
   95  mkdir Learning_Shell
   96  ls
   97  pwd
   98  ls
   99  cd Learning_Shell
  100  ls
  101  cp-r -/Downloads/data/Users/nelle/
  102  cp -r -/Downloads/data/Users/nelle
  103  cp -r ~/Downloads/data/Users/nelle
  104  cp -r ~/Downloads/data/Users/nelle ./
  105  cd nelle/
  106  ls
  107  ls -F
  108  cd molecules/
  109  ls
  110  wc * pdb
  111  wc-l * pdb
  112  wc -l * pdb
  113  man wc
  114  man wc -l * pdb > length.txtt
  115  ls
  116  cat length.txt
  117  nano length.txt
  118  cat length.txtt 
  119  clear
  120  man wc -l * pdb > length.txt
  121  man wc -l * . pdb > length.txt
  122  man wc -l * . pdb > length.txt
  123  ls
  124  wc -l * . pdb > length.txt
  125  wc -l *pdb>lengths.txt
  126  ls
  127  cat length.txt
  128  sort -n length.txt
  129  cat sorted length.txt
  130  ls
  131  head -2 sorted length.txt
  132  tail -3 sorted length.txt
  133  wc -l * pdb { sort -n | head -]
  134  wc -l * pdb [ sort -n | head -]
  135  wc -l * pdb [ sort -n ] head -l
  136  ls
  137  tail - 3 sorted length.txt
  138  cd Documents/
  139  ls
  140  cd Learning_Shell
  141  ls
  142  cd Users/nelle
  143  head - 2 sorted length.txt
  144  man wc -l * . pdb > length.txt
  145  man wc -l * . pdb > length.txt
  146  cd Users/nelle
  147  head -2 sorted length.txt
  148  tail - 3 sorted length.txt
  149  cd Documents/learning_shell/nelle/creatures
  150  cd Documents/learning shell/nelle/creatures
  151  cd Documents/learning_shell/nelle/creatures/
  152  ls
  153  cp * dat original *
  154  for filename in unicorn.dat basilisk.dat ; do head -3 $filename: done; done
  155  for filename basilisk.dat unicorn.dat
  156  cp basilisk.dat
  157  nls
  158  ls
  159  ls 'txt'
  160  ls '.txt'
  161  ls
  162  ~ Desktop
  163  ~ Documents
  164  ~ Pictures
  165  ~ basilisk.dat
  166  alas
  167  ls
  168  ls molecules
  169  cd molecules
  170  ls
  171  bash gostats stat
  172  expr 5+3
  173  expr 5 / 4
  174  for left in 2-; 3
  175  for left in 2-3; do for right in 2-3; do expr right + left;  done;  done
  176  expr 5/8
  177  expr 1+6
  178  expr 1 + 5
  179  expr 5 - 8
  180  cd molecules
  181  clear
  182  cd molecules
  183  cd Documents/learning_shell/nelle/molecules
  184  head -15 methane.pdb tail -5
  185  clear
  186  ls
  187  cd Documents/Learning_Shell/nelle
  188  cd molecules
  189  ls
  190  head -15 methane.pdb | tail -5
  191  nanpo
  192  nano
  193  clear
  194  head -15 methane.pdb | tail -5
  195  nano middle.sh
  196  bc- 1
  197  bc -1
  198  bc -l
  199  ls
  200  cd Documents
  201  ls
  202  pwd
  203  cd Documents/assignment
  204  cd assignment1
  205  pwd
  206  cd Desktop
  207  touch keyboard.txt
  208  ls
  209  man echo
  210  echo hello world
  211  echo {con,pre}{sent,fer} {s,ed}
  212  echo {con,pre}{sent,fer}{s,ed}
  213  man echo {
  214  date
  215  whoami
  216  man date
  217  man whoami
  218  cal 2000
  219  man cal2000
  220  man cal
  221  cal 2015
  222  cal 9 1752
  223  bc
  224  bc man
  225  man bc
  226  bc -l
  227  man bc
  228  bc -;
  229  bc -l
  230  echo 5+4 | bc -l
  231  echo 5+4
  232  bc -l
  233  echo 5+4 |
  234  echo 5+4 | bc
  235  man bc
  236  cal 9 1752
  237  pwd
  238  ls
  239  cdmobile
  240  cd mobile
  241  cd Desktop
  242  ls
  243  cd csci-2000
  244  ls
  245  cd Assignment-1
  246  cd Assignments
  247  cd Assignment-1
  248  ls
  249  cd cleaned_data
  250  ls
  251  ls -l
  252  HISTORY
  253  history
  254  cd ..
  255  pwd
  256  ls
  257  rm -rf cleaned_data
  258  ls
  259  tar xzvf cochlear-implant-trials-data-tar.gz
  260  tar xzvf cochlear-implant-trials-data.tar.gz
  261  ls -l
  262  pwd
  263  ls
  264  find . -name 'NOTES' -print
  265  rm ./jamesm/NOTES
  266  cd
  267  pwd
  268  cd mobile
  269  cd Desktop
  270  ls
  271  cd csci-2000
  272  cd Assignments
  273  cd Assignment-1
  274  ls
  275  cd data
  276  rm ./jamesm/NOTES
  277  rm ./Frank_Richard/NOTES
  278  ls
  279  ls -l
  280  cat data
  281  find . -name 'NOTES' -print
  282  rm ./Frank_Richard/NOTES
  283  find . -name 'NOTES' -print
  284  cd ..
  285  pwd
  286  cd Assignment-1
  287  pwd
  288  mkdir Assignment-1
  289  pwd
  290  ls
  291  rm Assignment-1
  292  rm -r Assignment-1
  293  ls
  294  cd ..
  295  pwd
  296  cd Assignments
  297  pwd
  298  l
  299  ls
  300  cd Assignment-1
  301  pwd
  302  ls
  303  mkdir cleaned_data
  304  pwd
  305  ls
  306  pwd
  307  cd data
  308  ls -l
  309  pwd
  310  cd alexander
  311  mv -f alexander cleaned_data
  312  mv -f alexander/ cleaned_data/
  313  mv -rf alexander/ cleaned_data/
  314  ls
  315  pwd
  316  mv -a alexander cleaned_data
  317  man mv
  318  mv -a alexander/ cleaned_data
  319  mv * ./cleaned_data
  320  mv -f alexander/ cleaned_data/
  321  mv alexander alexander.txt
  322  cd ..
  323  mv alexander alexander.txt
  324  ls
  325  ls -l
  326  cd alexander.txt
  327  ls -l
  328  cd ..
  329  pwd
  330  mv alexander.txt alexanderls
  331  cd ..
  332  ls
  333  cd data
  334  cd alexanders
  335  cd alexanderls
  336  mv alexanderls alexander
  337  cd ..
  338  mv alexanderls alexander
  339  ls
  340  ls -l
  341  cp -r alexander cp -r data/ cleaned_data
  342  cd ..
  343  pwd
  344  cp -r data/ cleaned_data
  345  ls
  346  ls -l
  347  pwd
  348  cd cleaned_data
  349  pwd
  350  ls -l
  351  ls
  352  rm data
  353  rm -r data
  354  ls
  355  cd ..
  356  ls
  357  cd data
  358  ls
  359  cd ..
  360  pwd
  361  ls
  362  cd data
  363  ls
  364  mv data*.DATA cleaned_data
  365  mv data*.DATA cleaned_data/
  366  mv d*.DATA cleaned_data/
  367  cp d*.DATA cleaned_data/
  368  mv d*.DATA cleaned_data/
  369  mv *.data cleaned_data/
  370  mv *.DATA cleaned_data/
  371  mv data* cleaned_data/
  372  cp data* cleaned_data/
  373  mv *.data cleaned_data/
  374  mv d*.data cleaned_data/
  375  mv d*.DATA cleaned_data/
  376  mv data*.DATA cleaned_data/
  377  mv data_*.DATA cleaned_data/
  378  pwd
  379  cd alexander
  380  mv data_*.DATA cleaned_data/
  381  mv data*.DATA cleaned_data/
  382  mv data*.DATA Assignment-1
  383  mv data*.DATA Assignment-1/
  384  mv d*.DATA Assignment-1/
  385  mv *.DATA* ~/cleaned_data/
  386  mv *.DATA ~/cleaned_data/
  387  mv *.DATA /cleaned_data/
  388  mv *.DATA /home/cleaned_data/
  389  find . -name "data*" -type f -exec mv {} ./ \;
  390  ls -l
  391  ls
  392  find . -name "data*" -type f -exec mv {} ./cleaned_data \;
  393  ls
  394  ls -;
  395  ls -l
  396  cd cleaned_data
  397  ls -l
  398  cd ..
  399  ls -l
  400  cd cleaned_data
  401  ls -l
  402  ls
  403  cd data
  404  cd ..
  405  cd dta
  406  cd data
  407  ls
  408  cd alexander
  409  ls
  410* 
  411  cd cleaned_file
  412  cd cleaned_data
  413  ls
  414  cd ..
  415  ls
  416  cd Bert
  417  ls
  418  mv audio* /Assignment-1/cleaned_data
  419  mv audio* /mobile/Desktop/csci-2000/Assignments/Assignment-1/cleaned_data
  420  mv audio* mobile/Desktop/csci-2000/Assignments/Assignment-1/cleaned_data
  421  mv audioresult-00215 cleaned_data
  422  cd ..
  423  cd cleaned_data
  424  ls
  425  ls -l
  426  ~cd ..
  427  cd ..
  428  ls
  429  cd cleaned_data
  430  ls
  431  cd ..
  432  cd data
  433  cd Bert
  434  cd cleaned_data
  435  cd ..
  436  cd alexander
  437  cd cleaned_data
  438  ls
  439  cd cleaned data
  440  pwd
  441  ls
  442  ls -l
  443  cd ..
  444  ls -l
  445  rm -rf data
  446  ls
  447  cd cleaned_data
  448  ls -l
  449  cd ..
  450  rm -rf cleaned_data
  451  rm-rf cochlear-implant-trials-data.tar.gz
  452  rm -rf cochlear-implant-trials-data.tar.gz
  453  ls -l
  454  tar xzvf cochlear-implant-trials-data.tar.gz
  455  ls -l
  456  find . -name 'NOTES' -print
  457  rm ./jamesm/NOTES
  458  cd data
  459  ls 
  460  cd ..
  461  cd data
  462  rm ./jamesm/NOTES
  463  rm ./Frank_Richard/NOTES
  464  ls -l
  465  find . -name 'NOTES' -print
  466  ls
  467  cd alexander
  468  cd ..
  469  mkdir cleaned_data
  470  ls
  471  cd data
  472  cd alexander
  473  ls
  474  mv data_216.DATA  data_288.DATA  data_337.DATA  data_379.DATA  data_420.DATA  data_471.DATA  data_536.DATA
  475  mv data_216.DATA  data_288.DATA  data_337.DATA  data_379.DATA  data_420.DATA  data_471.DATA  data_536.DATA cleaned_data
  476  mv data_216.DATA  data_288.DATA  data_337.DATA  data_379.DATA  data_420.DATA  data_471.DATA  data_536.DATA cleaned_data/
  477  mv data_216.DATA data_288.DATA data_337.DATA data_379.DATA data_420.DATA data_471.DATA data_536.DATA cleaned_data/
  478  mv data_216.DATA cleaned_data
  479  cd ..
  480  cd cleaned_data
  481  ls
  482  ls -l
  483  history
  484  cat history
  485  echo history > cleaning.sh
  486  ls
  487  rm -rf cleaning.sh
  488  cd ..
  489  echo history > cleaning.sh
  490  cat cleaning.sh
  491  rm -rf cleaning.sh
  492  ls
  493  history > cleaning.sh
